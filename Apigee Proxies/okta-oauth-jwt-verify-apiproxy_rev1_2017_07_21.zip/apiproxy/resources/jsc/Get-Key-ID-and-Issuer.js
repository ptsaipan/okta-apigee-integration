var raw_access_token = context.getVariable('request.formparam.assertion');
context.setVariable('raw_access_token', raw_access_token);
var unvalidated_access_token = jwtDecode(raw_access_token);

if (unvalidated_access_token === null) {
    throw new Error("Invalid access_token");
}

var unvalidated_kid = unvalidated_access_token.header.kid;
var unvalidated_iss = unvalidated_access_token.payload.iss;

var validated_kid = unvalidated_kid.replace(/[^a-zA-Z0-9-_]/g, "");

var validated_iss = false;
var domain = unvalidated_iss.split('/')[2];
var domain_parts = domain.split('.');
var domain_name = domain_parts.slice(domain_parts.length - 2, domain_parts.length).join('.')
if (domain_name !== "okta.com" && domain_name !== "oktapreview.com") {
    throw new Error("Invalid issuer");
} else {
    validated_iss = unvalidated_iss;
}

domain = validated_iss.split('//')[1];
context.setVariable('access_token.kid', validated_kid);
context.setVariable('access_token.iss', validated_iss);
context.setVariable('access_token.iss_domain', domain);
