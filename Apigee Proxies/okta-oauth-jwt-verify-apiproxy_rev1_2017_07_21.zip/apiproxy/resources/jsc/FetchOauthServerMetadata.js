//This JavaScript implements the httpClient intefrace defined by Apigee's
// JavaScript Object Model. Complete documentation is available at:
// http://apigee.com/docs/api-platform/content/javascript-object-model


// Send an HTTP GET to the URL that we construct
//var url = 'https://payaldemo.okta.com/oauth2/aus1xre2zv6jgVRMz1t7/.well-known/oauth-authorization-server';
var url = context.getVariable('access_token.iss') +  '/.well-known/oauth-authorization-server';
var req = new Request(url, 'GET',{});
var exchange = httpClient.send(req);
exchange.waitForComplete();
//print(exchange.getResponse().status);

if (exchange.getResponse().status != 200) {
 throw 'Error:' + exchange.getResponse().content;
}
var oauth_configuration_response=exchange.getResponse().content;
//print("JSON PAYLOAD" + openid_configuration_response);
context.setVariable('oauth_configuration_response', oauth_configuration_response);
