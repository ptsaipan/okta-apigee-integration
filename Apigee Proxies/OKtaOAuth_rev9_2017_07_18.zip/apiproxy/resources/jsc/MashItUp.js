//This JavaScript implements the httpClient intefrace defined by Apigee's
// JavaScript Object Model. Complete documentation is available at:
// http://apigee.com/docs/api-platform/content/javascript-object-model


var client_id = context.getVariable("client_id");
var client_secret = context.getVariable("client_secret");
//print('clinetid' + client_id);
var redirect_URI = context.getVariable("request.formparam.redirect_uri");
//var oktaApiToken = context.getVariable("oktaAPIToken");
var oktaApiToken = context.getVariable("private.encryptedAPIKey");
var domain = context.getVariable("oktaDomain");
var authorizationServerId = context.getVariable("oktaAuthServer");
//print("oktaApiToken" + oktaApiToken);
//print("domain" + domain);
//print("authorizationServerId" + authorizationServerId);

var headers = {
    'Authorization': oktaApiToken,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
};


// Send an HTTP GET to the URL that we construct
var url = 'https://' + domain +'/oauth2/v1/clients/' + client_id;
//print("URL" + url);
//print("domain" + domain);
//print("oktaApiToken" + oktaApiToken);
//print("oktaAuth Server" + authorizationServerId);

var req = new Request(url, 'GET', headers);
var exchange = httpClient.send(req);
exchange.waitForComplete();
if (exchange.getResponse().status != 200) {
    //Create App with Client ID
    var appendStr = client_id.substring(0, 4);
    var developerAppName = context.getVariable('apigee.developer.app.name');
    var clientAppName = developerAppName + '_' + appendStr;
    //print ("Append: "+ appendStr);
    var bodyObj = {
        'name': 'oidc_client',
        'label': clientAppName,
        'signOnMode': 'OPENID_CONNECT',
        'credentials': {
            'oauthClient': {
                'client_id': client_id,
                'client_secret': client_secret,
                'token_endpoint_auth_method': 'client_secret_post'
            }
        },
        'settings': {
            'oauthClient': {
                'client_uri': redirect_URI,
                'logo_uri': 'http://developer.okta.com/assets/images/logo-new.png',
                'redirect_uris': [
          'https://requestb.in/19se1ly1'
        ],
                'response_types': [
          'token',
          'id_token',
          'code'
        ],
                'grant_types': [
          'implicit',
          'authorization_code',
          'refresh_token',
          'password'
        ],
                'application_type': 'native'
            }
        }
    };


    //Get App ID for the 
    //var url = 'https://payaldemo.okta.com/oauth2/v1/clients/' + context.getVariable('request.formparam.client_id');
    var urlCA = 'https://' + domain +'/api/v1/apps';
    var req1 = new Request(urlCA, 'POST', headers, JSON.stringify(bodyObj));
    var exchange = httpClient.send(req1);
    exchange.waitForComplete();
    if (!exchange.isSuccess())
        throw 'Error contacting clientApp API';

    if (exchange.getResponse().status != 200)
        throw 'Error:' + exchange.getResponse().content;
    //get App ID from the created App response
    var appId = (exchange.getResponse().content).asJSON.id;
    //print("AppId: " + appId);
   // print("groupName: " + developerAppName);


    // get Group ID  /api/v1/groups?q=xxxx
    var urlgp = 'https://' + domain +'/api/v1/groups?q=' + developerAppName;
    //print(urlgp);
    var req1 = new Request(urlgp, 'GET', headers);
    var exchangeGrp = httpClient.send(req1);
    exchangeGrp.waitForComplete();
    if (!exchangeGrp.isSuccess())
        throw 'Error contacting groups API to get group id';

    if (exchangeGrp.getResponse().status != 200)
        throw 'Error groups API:' + exchangeGrp.getResponse().content;
    //get group id   
    
    
    //print("conent " + exchangeGrp.getResponse().content.asJSON);
    var resp = exchangeGrp.getResponse().content.asJSON;
    //print("groupId: " + resp[0].id);
    var groupId = resp[0].id;

    //Assign group to the ClientApp
    var urlAddGrp = 'https://' + domain +'/api/v1/apps/' + appId + '/groups/' + groupId;
    var req1 = new Request(urlAddGrp, 'PUT', headers);
    var exchange = httpClient.send(req1);
    exchange.waitForComplete();
    if (!exchange.isSuccess())
        throw 'Error contacting Apps API to add group';

    if (exchange.getResponse().status != 200)
        throw 'Error:' + exchange.getResponse().content;
   // print("Group " + groupId + " added to App " + appId);

    //Get policies for Auth Server
    var urlAuthServer = 'https://' + domain +'/api/v1/authorizationServers/' + authorizationServerId + '/policies';
   // print("URL authorizationServerId" + urlAuthServer); 
    var req1 = new Request(urlAuthServer, 'GET', headers);
    var exchange = httpClient.send(req1);
    exchange.waitForComplete();
    if (!exchange.isSuccess())
        throw 'Error contacting Auth Server API to get Policies';

    if (exchange.getResponse().status != 200)
        throw 'Error:' + exchange.getResponse().content;

    //extract _links/policies/href value
    var resp = exchange.getResponse().content.asJSON;
    var policyId = resp[0].id;
    var policyName = resp[0].name;
   // print("policyId " + policyId);
  //  print("policyName " + policyName);


    //Update Policy Add ClientApp
    var bodyObj = {
        "type": "OAUTH_AUTHORIZATION_POLICY",
        "status": "ACTIVE",
        "name": policyName,
        "description": "Default policy description",
        "priority": 1,
        "system": false,
        "conditions": {
            "clients": {
                "include": [
				client_id
			]
            }
        }
    };

    // Send an HTTP GET to the URL that we construct
    var policyIdUrl = 'https://' + domain +'/api/v1/authorizationServers/' + authorizationServerId + '/policies/' + policyId;
    var req1 = new Request(policyIdUrl, 'PUT', headers, JSON.stringify(bodyObj));
    var exchange = httpClient.send(req1);
    exchange.waitForComplete();
    if (!exchange.isSuccess())
        throw 'Error contacting update policies API';

    if (exchange.getResponse().status != 200)
        throw 'Error:' + exchange.getResponse().content;
    //get App ID from the created App response

}
