var oktaDomain = context.getVariable("oktaDomain");
context.setVariable('oktaDomain', oktaDomain);
var oktaAuthServer = context.getVariable("oktaAuthServer");
context.setVariable('oktaAuthServer', oktaAuthServer);
